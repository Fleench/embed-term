# embed-term

A basic module to embed a terminal-like input in Python applications.

Note: This will probbably change often and lacks documentation. Use at your own risk.
